import os
import json


def summarize_article(json_content):
    title = json_content.get("title", "Untitled")
    content = "\n".join(json_content.get("content", []))
    images = "\n".join(json_content.get("images", []))

    summary = f"Title: {title}\n\nContent:\n{content}\n\nImages:\n{images}\n"
    return summary


def summarize_json_files(processed_data_directory, final_data_directory):
    if not os.path.exists(final_data_directory):
        os.makedirs(final_data_directory)

    for filename in os.listdir(processed_data_directory):
        if filename.endswith(".json"):
            json_path = os.path.join(processed_data_directory, filename)
            with open(json_path, "r", encoding="utf-8") as json_file:
                json_content = json.load(json_file)

            summary = summarize_article(json_content)
            txt_filename = os.path.splitext(filename)[0] + ".txt"
            txt_path = os.path.join(final_data_directory, txt_filename)
            with open(txt_path, "w", encoding="utf-8") as txt_file:
                txt_file.write(summary)
            print(f"Summarized and saved TXT: {txt_path}")


def main():
    current_directory = os.getcwd()
    processed_data_directory = os.path.join(current_directory, "processed_data")
    final_data_directory = os.path.join(current_directory, "final_data")

    # Summarize JSON files and convert them to TXT
    summarize_json_files(processed_data_directory, final_data_directory)


if __name__ == "__main__":
    main()
