/* global tidioChatApi */
!function(){const t=document.querySelector(".sidebar-button button");t&&t.addEventListener("click",(()=>{tidioChatApi.open()}))}();