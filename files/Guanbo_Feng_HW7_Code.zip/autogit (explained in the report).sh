#!/bin/bash

REPO_PATH="/home/wwwroot/tarikvon.cn/public"
cd $REPO_PATH

GIT_STATUS=$(git status)
if [[ $GIT_STATUS == *"无文件要提交，干净的工作区"* ]]; then
  echo "Nothing to track."

else
  git pull
  git add .

  CURRENT_TIME=$(date "+%Y-%m-%d %H:%M:%S")
  git commit -am "$CURRENT_TIME"
  git push
fi
