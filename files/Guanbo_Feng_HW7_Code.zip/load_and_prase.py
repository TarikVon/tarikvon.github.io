import os
import json
from bs4 import BeautifulSoup


# Function to extract blog post information from XML content
def extract_blog_info(xml_content):
    soup = BeautifulSoup(xml_content, "lxml")

    # Find the main content div
    post_body = soup.find("div", class_="post-body", itemprop="articleBody")
    if not post_body:
        return None

    # Extract title from the <title> tag
    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else "Untitled"

    # Extract content from paragraphs and lists
    content = []
    for element in post_body.find_all(["p", "ul", "ol"]):
        content.append(element.get_text(strip=True))

    # Extract images
    images = []
    for img_tag in post_body.find_all("img"):
        images.append(img_tag.get("src"))

    # Create a dictionary with the extracted information
    blog_info = {"title": title, "content": content, "images": images}

    # Check if content is not empty
    if not content and not images:
        return None

    return blog_info


# Function to process XML files and convert them to JSON
def process_xml_files(raw_data_directory, processed_data_directory):
    if not os.path.exists(processed_data_directory):
        os.makedirs(processed_data_directory)

    valid_blog_infos = []
    for filename in os.listdir(raw_data_directory):
        if filename.endswith(".xml"):
            xml_path = os.path.join(raw_data_directory, filename)
            with open(xml_path, "r", encoding="utf-8") as xml_file:
                xml_content = xml_file.read()

            blog_info = extract_blog_info(xml_content)
            if blog_info:
                valid_blog_infos.append(blog_info)
            else:
                print(f"No valid blog information found in {xml_path}, skipped.")

    # Save valid blog infos to JSON files with consecutive numbering
    for index, blog_info in enumerate(valid_blog_infos, start=1):
        json_filename = f"index_{index}.json"
        json_path = os.path.join(processed_data_directory, json_filename)
        with open(json_path, "w", encoding="utf-8") as json_file:
            json.dump(blog_info, json_file, ensure_ascii=False, indent=4)
        print(f"Processed and saved JSON: {json_path}")


def main():
    current_directory = os.getcwd()
    raw_data_directory = os.path.join(current_directory, "raw_data")
    processed_data_directory = os.path.join(current_directory, "processed_data")

    # Process XML files and convert them to JSON
    process_xml_files(raw_data_directory, processed_data_directory)


if __name__ == "__main__":
    main()
