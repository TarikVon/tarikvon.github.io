import os
from collections import defaultdict
from lxml import etree


# Function to count file types in a directory
def count_file_types(directory):
    file_types_count = defaultdict(int)

    for root, dirs, files in os.walk(directory):
        for file in files:
            file_extension = os.path.splitext(file)[1].lower()
            file_types_count[file_extension] += 1

    return file_types_count


# Function to create the directory structure
def create_directory_structure(base_directory):
    structure = {"content": ["posts", "pages"], "assets": ["images/.png", "images/.gif", "images/.svg", "images/.jpg", "videos"], "styles": [], "scripts": []}

    for main_folder, subfolders in structure.items():
        for subfolder in subfolders:
            path = os.path.join(base_directory, main_folder, subfolder)
            os.makedirs(path, exist_ok=True)
        if not subfolders:  # If there are no subfolders, create the main folder itself
            path = os.path.join(base_directory, main_folder)
            os.makedirs(path, exist_ok=True)


# Function to convert HTML to XML using lxml
def convert_html_to_xml(html_content):
    parser = etree.HTMLParser()
    tree = etree.fromstring(html_content, parser)
    return etree.tostring(tree, pretty_print=True, encoding="unicode")


# Function to generate a unique filename to avoid conflicts
def generate_unique_filename(directory, filename):
    base, extension = os.path.splitext(filename)
    counter = 1
    unique_filename = f"{base}_{counter}{extension}"
    while os.path.exists(os.path.join(directory, unique_filename)):
        counter += 1
        unique_filename = f"{base}_{counter}{extension}"
    return unique_filename


# Function to copy and convert files to their respective folders
def copy_and_convert_files(base_directory, public_directory, raw_data_directory):
    extensions_mapping = {
        ".html": "content/posts",
        ".png": "assets/images/.png",
        ".gif": "assets/images/.gif",
        ".svg": "assets/images/.svg",
        ".jpg": "assets/images/.jpg",
        ".css": "styles",
        ".js": "scripts",
        ".txt": "content/pages",
        ".xml": "content/pages",
    }

    for root, dirs, files in os.walk(public_directory):
        for file in files:
            file_extension = os.path.splitext(file)[1].lower()
            destination_folder = extensions_mapping.get(file_extension)

            if destination_folder:
                source_path = os.path.join(root, file)
                destination_path = os.path.join(base_directory, destination_folder, file)

                # Ensure the destination filename is unique
                destination_filename = generate_unique_filename(os.path.join(base_directory, destination_folder), file)
                destination_path = os.path.join(base_directory, destination_folder, destination_filename)

                # Copy the file to the new directory structure
                os.makedirs(os.path.dirname(destination_path), exist_ok=True)
                with open(source_path, "rb") as src_file:
                    with open(destination_path, "wb") as dst_file:
                        dst_file.write(src_file.read())
                print(f"Copied: {source_path} to {destination_path}")

                # If the file is an HTML file, convert it to XML and copy to raw_data
                if file_extension == ".html":
                    with open(source_path, "r", encoding="utf-8") as html_file:
                        html_content = html_file.read()
                    xml_content = convert_html_to_xml(html_content)
                    xml_filename = generate_unique_filename(raw_data_directory, f"{os.path.splitext(file)[0]}.xml")
                    raw_data_path = os.path.join(raw_data_directory, xml_filename)
                    with open(raw_data_path, "w", encoding="utf-8") as xml_file:
                        xml_file.write(xml_content)
                    print(f"Converted and copied HTML to XML: {source_path} to {raw_data_path}")


def main():
    # Define the directories
    current_directory = os.getcwd()
    public_directory = os.path.join(current_directory, "public")
    archive_directory = os.path.join(current_directory, "archive")
    raw_data_directory = os.path.join(current_directory, "raw_data")

    # Check if the public directory exists
    if not os.path.exists(public_directory):
        print(f"The directory '{public_directory}' does not exist.")
        return

    # Create the archive and raw_data directory structures
    create_directory_structure(archive_directory)
    os.makedirs(raw_data_directory, exist_ok=True)

    # Copy and convert the files to the new directory structure
    copy_and_convert_files(archive_directory, public_directory, raw_data_directory)

    # Get the file types count
    file_types_count = count_file_types(archive_directory)

    # Output the statistics
    print("File types statistics in 'archive' folder:")
    for file_type, count in file_types_count.items():
        print(f"{file_type if file_type else 'No Extension'}: {count} file(s)")


if __name__ == "__main__":
    main()
